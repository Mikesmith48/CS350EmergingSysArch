/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Timer header */
#include <ti/drivers/Timer.h>


// Global flags
volatile unsigned char newStateFlag = 0;
volatile unsigned char endOfMessageFlag = 0;

// Global variables
unsigned char count = 0;
unsigned char current = 0;

// Morse Code States
enum MC_States { MC_SOS, MC_OK } MC_State;

// For messages:
// 0: Both LEDs off
// 1: Red LED on
// 2: Green LED on

// SOS message
unsigned char SOS_MESSAGE[] = {
   1,0,1,0,1,0,0,0,                 // S
   2,2,2,0,2,2,2,0,2,2,2,0,0,0,     // O
   1,0,1,0,1,                       // S
   0,0,0,0,0,0,0                    // Break between words
};

// OK message
unsigned char OK_MESSAGE[] = {
   2,2,2,0,2,2,2,0,2,2,2,0,0,0,     // O
   2,2,2,0,1,0,2,2,2,               // K
   0,0,0,0,0,0,0                    // Break between words
};


void State_Handler() {
    // State Transitions
    // Once a new state is entered, newStateFlag is lowered
    switch(MC_State) {
        case MC_SOS:
            if (newStateFlag && endOfMessageFlag) {
                MC_State = MC_OK;
                newStateFlag = 0;
            }
            break;
        case MC_OK:
            if (newStateFlag && endOfMessageFlag) {
                MC_State = MC_SOS;
                newStateFlag = 0;
            }
            break;
        default:
            MC_State = MC_SOS;
            break;
    }

    // Before getting to state actions, reset endOfMessageFlag
    endOfMessageFlag = 0;

    // State Actions
    switch(MC_State) {
        case MC_SOS:
            // Iterate through the message and execute the correct action based on
            // the led specified in the message array
            current = SOS_MESSAGE[count];
            switch(current) {
                case 0:
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                    break;
                case 1:
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                    break;
                case 2:
                    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
                    break;
                default:
                    break;
            }
            // Increment the count to preserve place in message through state interrupts
            count++;

            // If the end of the message is reached, raise a flag and reset the count
            if (count == ((sizeof(SOS_MESSAGE)/sizeof(SOS_MESSAGE[0])) - 1)) {
                endOfMessageFlag = 1;
                count = 0;
            }
            break;

        case MC_OK:
            current = OK_MESSAGE[count];
            switch(current) {
                case 0:
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                    break;
                case 1:
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                    break;
                case 2:
                    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
                    break;
                default:
                    break;
            }
            count++;

            if (count == ((sizeof(OK_MESSAGE)/sizeof(OK_MESSAGE[0])) - 1)) {
                endOfMessageFlag = 1;
                count = 0;
            }
            break;
    }
}

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    // Call the state handler every 500 ms
    State_Handler();
}

void initTimer(void)
{
 Timer_Handle timer0;
 Timer_Params params;
 Timer_init();
 Timer_Params_init(&params);
 // Set timer period to 500 ms
 params.period = 500000;
 params.periodUnits = Timer_PERIOD_US;
 params.timerMode = Timer_CONTINUOUS_CALLBACK;
 params.timerCallback = timerCallback;

 timer0 = Timer_open(CONFIG_TIMER_0, &params);
 if (timer0 == NULL) {
 /* Failed to initialized timer */
 while (1) {}
 }
 if (Timer_start(timer0) == Timer_STATUS_ERROR) {
 /* Failed to start timer */
 while (1) {}
 }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    // Raise a flag indicating the button was pressed
    newStateFlag = 1;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    // Raise a flag indicating the button was pressed
    newStateFlag = 1;
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    // Set initial state to display SOS message
    MC_State = MC_SOS;

    /* Call driver and timer init functions */
    GPIO_init();
    initTimer();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    // Loop forever
    while (1){}
}
